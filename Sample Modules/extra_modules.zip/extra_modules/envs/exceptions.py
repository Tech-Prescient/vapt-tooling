class EnvsValueException(Exception):
    pass
